$(document).ready(function () {
    var eyerad = 9; // 눈 돌아가는 범위 지름


    var touch = 0;

    function eyeball(e, name) {
        if (touch == 0) {
            var x = e.pageX;
            var y = e.pageY;

            var ex = $(name).offset().left + $(name).width() / 2;
            var ey = $(name).offset().top + $(name).height() / 2;

            var dx = ex - x;
            var dy = ey - y;
            var c = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
            var deg = Math.asin(dy / c) * 180 / Math.PI;
            if (ex > x) {
                deg = 180 - deg;
            } else if (ex <= x && ey <= y) {
                deg = deg + 360;
            }

            $(name).css({
                marginLeft: Math.cos(deg * Math.PI / 180) * eyerad + "px",
                marginTop: Math.sin(deg * Math.PI / 180) * eyerad * -1 + "px"
            });

        } else {
            $(name).css({
                marginLeft: "0px",
                marginTop: "0px"
            });
        }
    }

    $(window).mousemove(function () {
        eyeball(event, ".eye1");
        eyeball(event, ".eye2");
    });

    $("#left, #right").mouseover(function () {
        touch = 1;
    });
    $("#left, #right").mouseout(function () {
        touch = 0;
    });

    $("#txt").keydown(function (e) {
        var a = $(this).val();
        $("#demo1").text(a);
        eyetoText(event, ".eye1");
        eyetoText(event, ".eye2");
    });
    $("#pw").keydown(function (e) {
        var a = $(this).val();
        $("#demo2").text(a);
        eyetoText2(event, ".eye1");
        eyetoText2(event, ".eye2");
    });

    function eyetoText(e, name) {
        var x = $("#demo1").width() % $("#txt").width() + $("#demo1").offset().left;
        x = parseInt(x);
        var y = $("#demo1").offset().top - $("#demo1").height() / 2;

        var ex = $(name).offset().left + $(name).width() / 2;
        var ey = $(name).offset().top + $(name).height() / 2;

        var dx = ex - x;
        var dy = ey - y;
        var c = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
        var deg = Math.asin(dy / c) * 180 / Math.PI;
        if (ex > x) {
            deg = 180 - deg;
        } else if (ex <= x && ey <= y) {
            deg = deg + 360;
        }

        $(name).css({
            marginLeft: Math.cos(deg * Math.PI / 180) * eyerad + "px",
            marginTop: Math.sin(deg * Math.PI / 180) * eyerad * -1 + "px"
        });
    }

    function eyetoText2(e, name) {
        var x = $("#demo2").width() + $("#demo2").offset().left;
        x = parseInt(x);
        var y = $("#demo2").offset().top - $("#demo2").height() / 2;

        var ex = $(name).offset().left + $(name).width() / 2;
        var ey = $(name).offset().top + $(name).height() / 2;

        var dx = ex - x;
        var dy = ey - y;
        var c = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
        var deg = Math.asin(dy / c) * 180 / Math.PI;
        if (ex > x) {
            deg = 180 - deg;
        } else if (ex <= x && ey <= y) {
            deg = deg + 360;
        }

        $(name).css({
            marginLeft: Math.cos(deg * Math.PI / 180) * eyerad + "px",
            marginTop: Math.sin(deg * Math.PI / 180) * eyerad * -1 + "px"
        });
    }



});
